Phybots - a toolkit for making robotic things
Copyright (C) 2012 Jun KATO

version 1.0.0 for Processing
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

"Phybots" is a Java toolkit to prototype "robotic things."

This library is distributed under MPL 1.1/GPL 2.0/LGPL 2.1
triple license, except for the bundled libraries:

"napkit" GNU GPLv3
"bluecove" Apache v2

All source files which are not included in "src" directory can
be found in each jar files. Please extract them or visit our
website to read the entire source code.

Please see http://phybots.com/ for details.

- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
http://phybots.com/
arc (at) digitalmuseum.jp