/* -*- mode: java; c-basic-offset: 2; indent-tabs-mode: nil -*- */

/*
  Part of the Processing project - http://processing.org

  Copyright (c) 2008 Ben Fry and Casey Reas

  This program is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation; either version 2 of the License, or
  (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software Foundation,
  Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

package processing.app.linux;

import java.io.File;

import processing.app.Base;
import processing.app.Preferences;


public class Platform extends processing.app.Platform {

  public void init(Base base) {
    super.init(base);

    String javaVendor = System.getProperty("java.vendor");
    String javaVM = System.getProperty("java.vm.name");
    if (javaVendor == null ||
        (!javaVendor.contains("Sun") && !javaVendor.contains("Oracle")) ||
        javaVM == null || !javaVM.contains("Java")) {
      Base.showWarning("Not fond of this Java VM",
        "Processing requires Java 6 from Sun (i.e. the sun-java-jdk\n" +
        "package on Ubuntu). Other versions such as OpenJDK, IcedTea,\n" +
        "and GCJ are strongly discouraged. Among other things, you're\n" +
        "likely to run into problems with sketch window size and\n" +
        "placement. For more background, please read the wiki:\n" +
        "http://wiki.processing.org/w/Supported_Platforms#Linux", null);
    }
  }


  public void openURL(String url) throws Exception {
    if (openFolderAvailable()) {
      String launcher = Preferences.get("launcher");
      if (launcher != null) {
        Runtime.getRuntime().exec(new String[] { launcher, url });
      }
    }
  }


  public boolean openFolderAvailable() {
    if (Preferences.get("launcher") != null) {
      return true;
    }

    // Attempt to use xdg-open
    try {
      Process p = Runtime.getRuntime().exec(new String[] { "xdg-open" });
      p.waitFor();
      Preferences.set("launcher", "xdg-open");
      return true;
    } catch (Exception e) { }

    // Attempt to use gnome-open
    try {
      Process p = Runtime.getRuntime().exec(new String[] { "gnome-open" });
      p.waitFor();
      // Not installed will throw an IOException (JDK 1.4.2, Ubuntu 7.04)
      Preferences.set("launcher", "gnome-open");
      return true;
    } catch (Exception e) { }

    // Attempt with kde-open
    try {
      Process p = Runtime.getRuntime().exec(new String[] { "kde-open" });
      p.waitFor();
      Preferences.set("launcher", "kde-open");
      return true;
    } catch (Exception e) { }

    return false;
  }


  public void openFolder(File file) throws Exception {
    if (openFolderAvailable()) {
      String lunch = Preferences.get("launcher");
      try {
        String[] params = new String[] { lunch, file.getAbsolutePath() };
        //processing.core.PApplet.println(params);
        /*Process p =*/ Runtime.getRuntime().exec(params);
        /*int result =*/ //p.waitFor();
      } catch (Exception e) {
        e.printStackTrace();
      }
    } else {
      System.out.println("No launcher set, cannot open " +
                         file.getAbsolutePath());
    }
  }
}
